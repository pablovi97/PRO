package com.pablo.pribarcanvas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    pruebaCanvas canvas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        canvas = (pruebaCanvas) findViewById(R.id.canvas);

        canvas.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {


                float posx = event.getX();
                float posy = event.getY();

                canvas.poscocheX = posx;
                canvas.poscocheY = posy;
                canvas.invalidate();
                return false;
            }
        });


    }
}
