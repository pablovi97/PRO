package com.pablo.pribarcanvas;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.os.Build;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.View;

public class pruebaCanvas extends View {
    public pruebaCanvas(Context context) {
        super(context);
        init();
    }

    public pruebaCanvas(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    Paint pincelAzul;
    Paint pincelVerde;

    float poscocheX = -1;
    float  poscocheY = -1;

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);


        int ancho = canvas.getWidth();
        int largo = canvas.getHeight();
        canvas.drawRect(0, 0, ancho, largo, pincelAzul);
        if (poscocheX != -1 || poscocheY != -1) {
           canvas.drawCircle(poscocheX , poscocheY , 30 ,pincelVerde);
        }
    }

   // public pruebaCanvas(Context context, AttributeSet attrs, int defStyleAttr) {
     //   super(context, attrs, defStyleAttr);
   // }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public pruebaCanvas(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public void init() {
        pincelAzul = new Paint();
        pincelAzul.setColor(Color.BLUE);
        pincelAzul.setStrokeWidth(15);
        pincelVerde = new Paint();
        pincelVerde.setColor(Color.GREEN);
        pincelVerde.setStrokeWidth(15);
        pincelVerde.setStyle(Paint.Style.STROKE);


    }
}
